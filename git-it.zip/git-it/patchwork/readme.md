# Patchwork

![screenshot](https://raw.githubusercontent.com/jlord/patchwork/gh-pages/patchwork-ss.png)

This repository is a website hosted by [GitHub Pages](http://pages.github.com). It goes along with [Git-it](http://www.github.com/jlord/git-it-electron), a desktop application for learning Git and GitHub.

Users fork this repository and learn things like (forking) branching, adding collaborators, pulling in changes, pushing to a remote branch and submitting pull request. Once their pull request comes in, @reporobot rewrites the index.html here to include the user.

#### So much social coding goodness! :octocat:
